function loadPage(page) {
    fetch(`pages/${page}.html`)
        .then(response => response.text())
        .then(data => {
            document.getElementById("main-content").innerHTML = data;

            // Executa scripts específicos da página
            if (page === "dashboard") initDashboard();
            if (page === "alertas") initAlertas();
            if (page === "funcionarios") initFuncionarios();
        })
        .catch(error => console.error("Erro ao carregar página:", error));
}

// ================= DASHBOARD =================
const API_BASE = "http://localhost:8080";

async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Erro ao buscar dados: ${response.status}`);
    }
    return response.json();
}

function initDashboard() {
    const clock = document.getElementById("clock");
    if (clock) {
        setInterval(() => {
            const now = new Date();
            clock.innerText = now.toLocaleString();
        }, 1000);
    }

    carregarDashboard();
}

async function carregarDashboard() {
    try {
        const [deteccoes, alertas] = await Promise.all([
            fetchJson(`${API_BASE}/api/deteccoes/listar`),
            fetchJson(`${API_BASE}/alerta/listar`)
        ]);

        const total = Array.isArray(deteccoes) ? deteccoes.length : 0;
        const completos = Array.isArray(deteccoes)
            ? deteccoes.filter(item => item && item.usandoEpi).length
            : 0;
        const incompletos = total - completos;
        const percentual = total > 0 ? Math.round((completos / total) * 100) : 0;

        document.getElementById("pessoas").innerText = total;
        document.getElementById("conformidade").innerText = `${percentual}%`;
        document.getElementById("semEpi").innerText = incompletos;

        const alertasContainer = document.getElementById("alertas");
        if (Array.isArray(alertas) && alertas.length > 0) {
            alertasContainer.innerHTML = alertas.map(alerta => `
                <div class="alert-item">
                    ${alerta.deteccao ? `Detecção ${alerta.deteccao.deteccaoId} - ${alerta.deteccao.status}` : 'Alerta recebido'}
                </div>
            `).join("");
        } else {
            alertasContainer.innerHTML = '<div class="alert-item">Nenhum alerta encontrado.</div>';
        }

        const tabela = document.getElementById("tabelaRegistros");
        if (Array.isArray(deteccoes) && deteccoes.length > 0) {
            tabela.innerHTML = deteccoes.slice(0, 8).map(item => {
                const hora = item.dataHora ? new Date(item.dataHora).toLocaleTimeString() : "--";
                const statusClass = item.usandoEpi ? "status-ok" : "status-alert";
                return `
                    <tr>
                        <td>${item.funcionario?.nomeFuncionario || "Não identificado"}</td>
                        <td>${item.maquina?.nome || item.camera?.localizacao || "Sem área"}</td>
                        <td class="${statusClass}">${item.status || "INCOMPLETO"}</td>
                        <td>${hora}</td>
                    </tr>
                `;
            }).join("");
        } else {
            tabela.innerHTML = '<tr><td colspan="4">Nenhum registro encontrado.</td></tr>';
        }
    } catch (error) {
        console.error(error);
        document.getElementById("pessoas").innerText = "0";
        document.getElementById("conformidade").innerText = "0%";
        document.getElementById("semEpi").innerText = "0";
        document.getElementById("alertas").innerHTML = '<div class="alert-item">Não foi possível carregar os dados do backend.</div>';
        document.getElementById("tabelaRegistros").innerHTML = '<tr><td colspan="4">Falha ao carregar registros.</td></tr>';
    }
}

// ================= ALERTAS =================
function initAlertas() {
    const container = document.getElementById("lista-alertas");

    container.innerHTML = `
        <div class="alert-item">Funcionário ID 55 - Sem Luva</div>
        <div class="alert-item">Funcionário ID 88 - Sem Óculos</div>
        <div class="alert-item">Funcionário ID 102 - Sem Capacete</div>
    `;
}

// ================= FUNCIONÁRIOS =================
function initFuncionarios() {
    const tabela = document.getElementById("lista-funcionarios");

    tabela.innerHTML = `
        <tr>
            <td>João Silva</td>
            <td>Produção</td>
            <td>Ativo</td>
        </tr>
        <tr>
            <td>Maria Souza</td>
            <td>Carga</td>
            <td>Ativo</td>
        </tr>
    `;
}

// Carrega dashboard ao iniciar
loadPage("dashboard");