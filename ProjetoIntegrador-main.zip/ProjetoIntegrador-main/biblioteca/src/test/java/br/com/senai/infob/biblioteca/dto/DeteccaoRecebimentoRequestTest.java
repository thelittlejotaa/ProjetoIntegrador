package br.com.senai.infob.biblioteca.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import br.com.senai.infob.biblioteca.models.Deteccao;

class DeteccaoRecebimentoRequestTest {

    @Test
    void deveCalcularStatusIncompletoParaDeteccaoParcial() {
        DeteccaoRecebimentoRequest request = new DeteccaoRecebimentoRequest();
        request.setCameraId(1);
        request.setDataHora(LocalDateTime.of(2026, 7, 10, 11, 30));
        request.setCapacete(true);
        request.setColete(true);
        request.setSapato(false);

        Deteccao deteccao = request.toDeteccao(null, null);

        assertFalse(deteccao.isUsandoEpi());
        assertEquals("INCOMPLETO", deteccao.getStatus());
    }

    @Test
    void deveCriarUmaDeteccaoPorItemDaLista() {
        DeteccaoRecebimentoRequest request = new DeteccaoRecebimentoRequest();
        request.setCameraId(2);
        request.setDataHora(LocalDateTime.of(2026, 7, 10, 12, 0));

        DeteccaoDTO primeira = new DeteccaoDTO();
        primeira.setPessoaDetectada(1);
        primeira.setCapacete(true);
        primeira.setColete(true);
        primeira.setSapato(false);
        primeira.setConfianca(0.93);
        primeira.setTempoProcessamento(28);

        DeteccaoDTO segunda = new DeteccaoDTO();
        segunda.setPessoaDetectada(2);
        segunda.setCapacete(true);
        segunda.setColete(true);
        segunda.setSapato(true);
        segunda.setConfianca(0.97);
        segunda.setTempoProcessamento(28);

        request.setDeteccoes(List.of(primeira, segunda));

        List<Deteccao> deteccoes = request.toDeteccoes(null, null);

        assertEquals(2, deteccoes.size());
        assertEquals("INCOMPLETO", deteccoes.get(0).getStatus());
        assertEquals("OK", deteccoes.get(1).getStatus());
        assertTrue(deteccoes.get(1).isUsandoEpi());
    }
}
