package br.com.senai.infob.biblioteca;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import br.com.senai.infob.biblioteca.dto.DeteccaoDTO;
import br.com.senai.infob.biblioteca.dto.DeteccaoRecebimentoRequest;
import br.com.senai.infob.biblioteca.models.Camera;
import br.com.senai.infob.biblioteca.models.Deteccao;
import br.com.senai.infob.biblioteca.models.Maquina;

class DeteccaoRecebimentoRequestTest {

    @Test
    void deveConverterPayloadEmLoteParaDeteccoes() {
        DeteccaoRecebimentoRequest request = new DeteccaoRecebimentoRequest();
        request.setCameraId(1);
        request.setMaquinaId(2);
        request.setDataHora(LocalDateTime.of(2026, 7, 10, 15, 30));

        DeteccaoDTO deteccaoDTO = new DeteccaoDTO();
        deteccaoDTO.setPessoaDetectada(1);
        deteccaoDTO.setCapacete(true);
        deteccaoDTO.setColete(true);
        deteccaoDTO.setSapato(false);
        deteccaoDTO.setConfianca(0.94);
        deteccaoDTO.setTempoProcessamento(31);

        request.setDeteccoes(List.of(deteccaoDTO));

        Camera camera = new Camera();
        camera.setCameraId(1);

        Maquina maquina = new Maquina();
        maquina.setMaquinaId(2);

        List<Deteccao> deteccoes = request.toDeteccoes(camera, maquina);

        assertEquals(1, deteccoes.size());
        Deteccao deteccao = deteccoes.get(0);
        assertEquals(1, deteccao.getPessoaDetectada());
        assertTrue(deteccao.isCapacete());
        assertTrue(deteccao.isColete());
        assertFalse(deteccao.isSapato());
        assertEquals(BigDecimal.valueOf(0.94), deteccao.getConfianca());
        assertEquals(31, deteccao.getTempoProcessamento());
        assertFalse(deteccao.isUsandoEpi());
        assertEquals("INCOMPLETO", deteccao.getStatus());
    }
}
