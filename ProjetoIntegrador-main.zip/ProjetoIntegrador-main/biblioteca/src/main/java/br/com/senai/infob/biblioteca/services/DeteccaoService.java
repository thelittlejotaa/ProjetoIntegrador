package br.com.senai.infob.biblioteca.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senai.infob.biblioteca.dto.DeteccaoRecebimentoRequest;
import br.com.senai.infob.biblioteca.models.Alerta;
import br.com.senai.infob.biblioteca.models.Camera;
import br.com.senai.infob.biblioteca.models.Deteccao;
import br.com.senai.infob.biblioteca.models.Maquina;
import br.com.senai.infob.biblioteca.repositories.AlertaRepository;
import br.com.senai.infob.biblioteca.repositories.CameraRepository;
import br.com.senai.infob.biblioteca.repositories.DeteccaoRepository;
import br.com.senai.infob.biblioteca.repositories.MaquinaRepository;

@Service
public class DeteccaoService {
    @Autowired
    public DeteccaoRepository deteccaoRepository;

    @Autowired
    public CameraRepository cameraRepository;

    @Autowired
    public MaquinaRepository maquinaRepository;

    @Autowired
    public AlertaRepository alertaRepository;

    public Long count() {
        return deteccaoRepository.count();
    }

    public Deteccao salvar(Deteccao deteccao) {
        return deteccaoRepository.save(deteccao);
    }

    public List<Deteccao> receberDeteccoes(DeteccaoRecebimentoRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("O corpo da requisição não pode ser vazio.");
        }
        if (request.getCameraId() == null) {
            throw new IllegalArgumentException("cameraId é obrigatório.");
        }
        if (request.getMaquinaId() == null) {
            throw new IllegalArgumentException("maquinaId é obrigatório.");
        }

        Camera camera = cameraRepository.findById(request.getCameraId())
                .orElseThrow(() -> new IllegalArgumentException("Camera não encontrada."));
        Maquina maquina = maquinaRepository.findById(request.getMaquinaId())
                .orElseThrow(() -> new IllegalArgumentException("Máquina não encontrada."));

        List<Deteccao> deteccoes = request.toDeteccoes(camera, maquina);
        List<Deteccao> salvas = new ArrayList<>();

        for (Deteccao deteccao : deteccoes) {
            if (deteccao.getDataHora() == null) {
                deteccao.setDataHora(request.getDataHora());
            }
            Deteccao salva = deteccaoRepository.save(deteccao);
            if (!salva.isUsandoEpi()) {
                criarAlerta(salva);
            }
            salvas.add(salva);
        }

        return salvas;
    }

    private void criarAlerta(Deteccao deteccao) {
        Alerta alerta = new Alerta();
        alerta.setDeteccao(deteccao);
        alerta.setTipo("SEM_EPI");
        alerta.setMensagem("Detecção incompleta: ausência de um ou mais EPIs.");
        alerta.setStatus("pendente");
        alerta.setUsuario(null);
        alertaRepository.save(alerta);
    }

    public boolean delete(Integer id) {
        Deteccao deteccao = deteccaoRepository.findById(id).orElse(null);
        if (deteccao != null) {
            deteccaoRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public boolean update(Deteccao deteccao) {
        deteccaoRepository.save(deteccao);
        return true;
    }

    public Deteccao atualizar(Deteccao deteccao, Integer id) {
        Deteccao e = buscar(id);
        if (e != null) {
            deteccao.setDeteccaoId(id);
            return deteccaoRepository.save(deteccao);
        }
        return null;
    }

    public Deteccao buscar(Integer id) {
        return deteccaoRepository.findById(id).orElse(null);
    }

    public List<Deteccao> listar() {
        return deteccaoRepository.findAll();
    }
}
