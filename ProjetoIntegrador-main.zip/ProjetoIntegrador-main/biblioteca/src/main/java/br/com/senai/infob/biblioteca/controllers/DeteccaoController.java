package br.com.senai.infob.biblioteca.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.senai.infob.biblioteca.dto.DeteccaoRecebimentoRequest;
import br.com.senai.infob.biblioteca.models.Deteccao;
import br.com.senai.infob.biblioteca.services.DeteccaoService;

@RestController
@RequestMapping(path = {"/Deteccao", "/api/deteccoes"})
public class DeteccaoController {
    @Autowired
    public DeteccaoService deteccaoService;

    @GetMapping("/count")
    public Long count() {
        return deteccaoService.count();
    }

    @PostMapping("/salvar")
    public Deteccao salvar(@RequestBody Deteccao deteccao) {
        return deteccaoService.salvar(deteccao);
    }

    @PostMapping
    public List<Deteccao> receber(@RequestBody DeteccaoRecebimentoRequest request) {
        return deteccaoService.receberDeteccoes(request);
    }

    @PostMapping("/receber")
    public List<Deteccao> receberCompatibilidade(@RequestBody DeteccaoRecebimentoRequest request) {
        return deteccaoService.receberDeteccoes(request);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Integer id) {
        boolean deletou = deteccaoService.delete(id);
        if (deletou) {
            return "user removido";
        }
        return " falha ao remover";
    }

    @PutMapping("/atualizar/{id}")
    public Deteccao atualizar(@PathVariable Integer id, @RequestBody Deteccao deteccao) {
        return deteccaoService.atualizar(deteccao, id);
    }

    @GetMapping("/search/{id}")
    public Deteccao buscar(@PathVariable Integer id) {
        return deteccaoService.buscar(id);
    }

    @GetMapping("/listar")
    public List<Deteccao> listar() {
        return deteccaoService.listar();
    }
}
