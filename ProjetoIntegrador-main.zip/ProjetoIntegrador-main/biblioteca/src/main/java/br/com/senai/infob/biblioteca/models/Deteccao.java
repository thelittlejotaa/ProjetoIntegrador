﻿package br.com.senai.infob.biblioteca.models;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "deteccao")
public class Deteccao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "deteccao_id")
    private int deteccaoId;

    @Column(name = "pessoa_detectada", nullable = false)
    private int pessoaDetectada;

    @Column(name = "capacete", nullable = false)
    private boolean capacete;

    @Column(name = "colete", nullable = false)
    private boolean colete;

    @Column(name = "sapato", nullable = false)
    private boolean sapato;

    @Column(name = "usando_epi", nullable = false)
    private boolean usandoEpi;

    @Column(name = "confianca", nullable = false)
    private BigDecimal confianca;

    @Column(name = "tempo_processamento")
    private Integer tempoProcessamento;

    @Column(name = "status")
    private String status;

    @Column(name = "data_hora", columnDefinition = "TIMESTAMP", nullable = false)
    private LocalDateTime dataHora;

    @ManyToOne(optional = true)
    @JoinColumn(name = "funcionario_id", nullable = true)
    private Funcionario funcionario;

    @ManyToOne(optional = true)
    @JoinColumn(name = "camera_id", nullable = true)
    private Camera camera;

    @ManyToOne(optional = true)
    @JoinColumn(name = "maquina_id", nullable = true)
    private Maquina maquina;

    public Deteccao() {
        atualizarStatus();
    }

    public Deteccao(int deteccaoId, int pessoaDetectada, boolean capacete, boolean colete, boolean sapato,
            BigDecimal confianca, Integer tempoProcessamento, LocalDateTime dataHora, Funcionario funcionario,
            Camera camera, Maquina maquina) {
        this.deteccaoId = deteccaoId;
        this.pessoaDetectada = pessoaDetectada;
        this.capacete = capacete;
        this.colete = colete;
        this.sapato = sapato;
        this.confianca = confianca;
        this.tempoProcessamento = tempoProcessamento;
        this.dataHora = dataHora;
        this.funcionario = funcionario;
        this.camera = camera;
        this.maquina = maquina;
        atualizarStatus();
    }

    @PrePersist
    @PreUpdate
    public void atualizarStatus() {
        this.usandoEpi = this.capacete && this.colete && this.sapato;
        this.status = this.usandoEpi ? "OK" : "INCOMPLETO";
    }

    public int getDeteccaoId() {
        return deteccaoId;
    }

    public void setDeteccaoId(int deteccaoId) {
        this.deteccaoId = deteccaoId;
    }

    public int getPessoaDetectada() {
        return pessoaDetectada;
    }

    public void setPessoaDetectada(int pessoaDetectada) {
        this.pessoaDetectada = pessoaDetectada;
    }

    public boolean isCapacete() {
        return capacete;
    }

    public void setCapacete(boolean capacete) {
        this.capacete = capacete;
        atualizarStatus();
    }

    public boolean isColete() {
        return colete;
    }

    public void setColete(boolean colete) {
        this.colete = colete;
        atualizarStatus();
    }

    public boolean isSapato() {
        return sapato;
    }

    public void setSapato(boolean sapato) {
        this.sapato = sapato;
        atualizarStatus();
    }

    public BigDecimal getConfianca() {
        return confianca;
    }

    public void setConfianca(BigDecimal confianca) {
        this.confianca = confianca;
    }

    public Integer getTempoProcessamento() {
        return tempoProcessamento;
    }

    public void setTempoProcessamento(Integer tempoProcessamento) {
        this.tempoProcessamento = tempoProcessamento;
    }

    public boolean isUsandoEpi() {
        return usandoEpi;
    }

    public void setUsandoEpi(boolean usandoEpi) {
        this.usandoEpi = usandoEpi;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Camera getCamera() {
        return camera;
    }

    public void setCamera(Camera camera) {
        this.camera = camera;
    }

    public Maquina getMaquina() {
        return maquina;
    }

    public void setMaquina(Maquina maquina) {
        this.maquina = maquina;
    }
}
