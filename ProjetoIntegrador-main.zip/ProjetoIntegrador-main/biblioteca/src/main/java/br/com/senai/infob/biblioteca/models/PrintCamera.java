package br.com.senai.infob.biblioteca.models;


import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="print_camera")
public class PrintCamera {
    
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    private int printCameraId;
    
    @Column(name="validacao")
    private boolean validacao;

    @Column(name="url_imagem")
    private String urlImagem;

    @Column(name="data_hora", columnDefinition = "TIMESTAMP")
    private LocalDateTime dataHora;

    @ManyToOne(optional = true)
    @JoinColumn(name = "deteccao_id", nullable = true)
    private Deteccao deteccao;

    public PrintCamera() {
    }
    public PrintCamera(int printCameraId, boolean validacao, String urlImagem, LocalDateTime dataHora, Deteccao deteccao) {
        this.printCameraId = printCameraId;
        this.validacao = validacao;
        this.urlImagem = urlImagem;
        this.dataHora = dataHora;
        this.deteccao = deteccao;
    }
    public int getPrintCameraId() {
        return printCameraId;
    }
    public void setPrintCameraId(int printCameraId) {
        this.printCameraId = printCameraId;
    }
    public boolean isValidacao() {
        return validacao;
    }
    public void setValidacao(boolean validacao) {
        this.validacao = validacao;
    }
    public String getUrlImagem() {
        return urlImagem;
    }
    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }
    public LocalDateTime getDataHora() {
        return dataHora;
    }
    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
    public Deteccao getDeteccao() {
        return deteccao;
    }

    public void setDeteccao(Deteccao deteccao) {
        this.deteccao = deteccao;
    }

    
}

