package br.com.senai.infob.biblioteca.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import br.com.senai.infob.biblioteca.models.Camera;
import br.com.senai.infob.biblioteca.models.Deteccao;
import br.com.senai.infob.biblioteca.models.Maquina;

public class DeteccaoRecebimentoRequest {

    private Integer cameraId;
    private Integer maquinaId;
    private LocalDateTime dataHora;
    private Boolean capacete;
    private Boolean colete;
    private Boolean sapato;
    private List<DeteccaoDTO> deteccoes;

    public DeteccaoRecebimentoRequest() {
    }

    public Integer getCameraId() {
        return cameraId;
    }

    public void setCameraId(Integer cameraId) {
        this.cameraId = cameraId;
    }

    public Integer getMaquinaId() {
        return maquinaId;
    }

    public void setMaquinaId(Integer maquinaId) {
        this.maquinaId = maquinaId;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public Boolean getCapacete() {
        return capacete;
    }

    public void setCapacete(Boolean capacete) {
        this.capacete = capacete;
    }

    public Boolean getColete() {
        return colete;
    }

    public void setColete(Boolean colete) {
        this.colete = colete;
    }

    public Boolean getSapato() {
        return sapato;
    }

    public void setSapato(Boolean sapato) {
        this.sapato = sapato;
    }

    public List<DeteccaoDTO> getDeteccoes() {
        return deteccoes;
    }

    public void setDeteccoes(List<DeteccaoDTO> deteccoes) {
        this.deteccoes = deteccoes;
    }

    public Deteccao toDeteccao(Camera camera, Maquina maquina) {
        DeteccaoDTO dto = new DeteccaoDTO();
        dto.setCapacete(this.capacete);
        dto.setColete(this.colete);
        dto.setSapato(this.sapato);
        return dto.toDeteccao(camera, maquina);
    }

    public List<Deteccao> toDeteccoes(Camera camera, Maquina maquina) {
        if (this.deteccoes != null && !this.deteccoes.isEmpty()) {
            List<Deteccao> resultado = new ArrayList<>();
            for (DeteccaoDTO item : this.deteccoes) {
                Deteccao deteccao = item.toDeteccao(camera, maquina);
                deteccao.setDataHora(this.dataHora);
                resultado.add(deteccao);
            }
            return resultado;
        }

        List<Deteccao> resultado = new ArrayList<>();
        Deteccao deteccao = this.toDeteccao(camera, maquina);
        deteccao.setDataHora(this.dataHora);
        resultado.add(deteccao);
        return resultado;
    }
}
