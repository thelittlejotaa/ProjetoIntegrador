package br.com.senai.infob.biblioteca.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="funcionario_epi")
public class FuncionarioEpi {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    private int funcionarioEpiId; 
    
    @Column(name="funcionario_id")
    private int funcionarioId;

    @Column(name="epi_id")
    private int epiId;

    @Column(name="obrigatorio")
    private boolean obrigatorio;

    public FuncionarioEpi() {
    }

    public FuncionarioEpi(int funcionarioEpiId, int funcionarioId, int epiId, boolean obrigatorio) {
        this.funcionarioEpiId = funcionarioEpiId;
        this.funcionarioId = funcionarioId;
        this.epiId = epiId;
        this.obrigatorio = obrigatorio;
    }

    public int getFuncionarioEpiId() {
        return funcionarioEpiId;
    }

    public void setFuncionarioEpiId(int funcionarioEpiId) {
        this.funcionarioEpiId = funcionarioEpiId;
    }

    public int getFuncionarioId() {
        return funcionarioId;
    }

    public void setFuncionarioId(int funcionarioId) {
        this.funcionarioId = funcionarioId;
    }

    public int getEpiId() {
        return epiId;
    }

    public void setEpiId(int epiId) {
        this.epiId = epiId;
    }

    public boolean isObrigatorio() {
        return obrigatorio;
    }

    public void setObrigatorio(boolean obrigatorio) {
        this.obrigatorio = obrigatorio;
    }  
}
