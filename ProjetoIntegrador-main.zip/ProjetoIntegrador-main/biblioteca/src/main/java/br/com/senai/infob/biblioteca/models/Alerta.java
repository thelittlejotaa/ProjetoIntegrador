package br.com.senai.infob.biblioteca.models;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="alerta")
public class Alerta {
    
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    private int alertaId;

    @Column(name="tipo")
    private String tipo;

    @Column(name="mensagem")
    private String mensagem;

    @Column(name="status")
    private String status;

    @ManyToOne
    @JoinColumn(name = "deteccao_id")
    private Deteccao deteccao;

    @ManyToOne(optional = true)
    @JoinColumn(name = "usuario_id", nullable = true)
    private Usuario usuario;
    public Alerta() {
    }
    public Alerta(int alertaId, String tipo, String mensagem, String status, Deteccao deteccao, Usuario usuario) {
        this.alertaId = alertaId;
        this.tipo = tipo;
        this.mensagem = mensagem;
        this.status = status;
        this.deteccao = deteccao;
        this.usuario = usuario;
    }
    public int getAlertaId() {
        return alertaId;
    }
    public void setAlertaId(int alertaId) {
        this.alertaId = alertaId;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public String getMensagem() {
        return mensagem;
    }
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Deteccao getDeteccao() {
        return deteccao;
    }
    public void setDeteccao(Deteccao deteccao) {
        this.deteccao = deteccao;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }


}
