package br.com.senai.infob.biblioteca.dto;

import java.math.BigDecimal;

import br.com.senai.infob.biblioteca.models.Camera;
import br.com.senai.infob.biblioteca.models.Deteccao;
import br.com.senai.infob.biblioteca.models.Maquina;

public class DeteccaoDTO {

    private Integer pessoaDetectada;
    private Integer cameraId;
    private Integer maquinaId;
    private Boolean capacete;
    private Boolean colete;
    private Boolean sapato;
    private Double confianca;
    private Integer tempoProcessamento;

    public DeteccaoDTO() {
    }

    public Integer getPessoaDetectada() {
        return pessoaDetectada;
    }

    public void setPessoaDetectada(Integer pessoaDetectada) {
        this.pessoaDetectada = pessoaDetectada;
    }

    public Integer getCameraId() {
        return cameraId;
    }

    public void setCameraId(Integer cameraId) {
        this.cameraId = cameraId;
    }

    public Integer getMaquinaId() {
        return maquinaId;
    }

    public void setMaquinaId(Integer maquinaId) {
        this.maquinaId = maquinaId;
    }

    public Boolean getCapacete() {
        return capacete;
    }

    public void setCapacete(Boolean capacete) {
        this.capacete = capacete;
    }

    public Boolean getColete() {
        return colete;
    }

    public void setColete(Boolean colete) {
        this.colete = colete;
    }

    public Boolean getSapato() {
        return sapato;
    }

    public void setSapato(Boolean sapato) {
        this.sapato = sapato;
    }

    public Double getConfianca() {
        return confianca;
    }

    public void setConfianca(Double confianca) {
        this.confianca = confianca;
    }

    public Integer getTempoProcessamento() {
        return tempoProcessamento;
    }

    public void setTempoProcessamento(Integer tempoProcessamento) {
        this.tempoProcessamento = tempoProcessamento;
    }

    public Deteccao toDeteccao(Camera camera, Maquina maquina) {
        Deteccao deteccao = new Deteccao();
        deteccao.setCamera(camera);
        deteccao.setMaquina(maquina);
        deteccao.setPessoaDetectada(this.pessoaDetectada != null ? this.pessoaDetectada : 0);
        deteccao.setCapacete(Boolean.TRUE.equals(this.capacete));
        deteccao.setColete(Boolean.TRUE.equals(this.colete));
        deteccao.setSapato(Boolean.TRUE.equals(this.sapato));
        deteccao.setConfianca(this.confianca != null ? BigDecimal.valueOf(this.confianca) : BigDecimal.ZERO);
        deteccao.setTempoProcessamento(this.tempoProcessamento);
        return deteccao;
    }
}
